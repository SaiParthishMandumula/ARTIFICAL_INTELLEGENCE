Name:Sai Parthish Mandumula
UTA ID:	1002022847
Net ID:	sxm2847
Language: Python 3

Task 2:
Given observations are used as-is, and Combinations and truth value dictionary is initialized of given arguments.
"PopulateBaysianNetwork" consists of the following functions To calculate probability - computeProbability()
Results are shown in the console for the given arguments

How to run:
python bnet.py [arguments]
